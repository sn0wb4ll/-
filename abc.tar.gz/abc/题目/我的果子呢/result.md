# Online Solidity Decompiler

## Address

0x5ede8836841ad3790bc227d88a12ec363ca8682b [etherscan.io]

## Public Methods

Method names cached from 4byte.directory.

0x9189fec1 guess(uint256)

## Internal Methods

func_0082(arg0) returns (r0)

## Decompilation

```js
contract Contract {
    function main() {
        memory[0x40:0x60] = 0x80;
    
        if (msg.data.length < 0x04) { revert(memory[0x00:0x00]); }
    
        var var0 = msg.data[0x00:0x20] / 0x0100000000000000000000000000000000000000000000000000000000 & 0xffffffff;
    
        if (var0 != 0x9189fec1) { revert(memory[0x00:0x00]); }
    
        var var1 = msg.value;
    
        if (var1) { revert(memory[0x00:0x00]); }
    
        var1 = 0x6c;
        var var2 = msg.data[0x04:0x24];
        var1 = func_0082(var2);
        var temp0 = memory[0x40:0x60];
        memory[temp0:temp0 + 0x20] = var1;
        var temp1 = memory[0x40:0x60];
        return memory[temp1:temp1 + (temp0 + 0x20) - temp1];
    }
    
    function func_0082(var arg0) returns (var r0) {
        var var0 = 0x00;
        var temp0 = arg0;
        var temp1 = memory[0x40:0x60];
        memory[temp1:temp1 + 0x20] = temp0;
        var temp2 = memory[0x40:0x60];
        var var1 = keccak256(memory[temp2:temp2 + (temp1 + 0x20) - temp2]);
        var temp3 = memory[0x40:0x60];
        memory[temp3:temp3 + 0x20] = temp0;
        var temp4 = memory[0x40:0x60];
        var temp5 = keccak256(memory[temp4:temp4 + (temp3 + 0x20) - temp4]);
        var temp6 = memory[0x40:0x60];
        memory[temp6:temp6 + 0x20] = storage[0x01] * storage[0x02] + storage[0x03];
        var temp7 = memory[0x40:0x60];
    
        if (keccak256(memory[temp7:temp7 + (temp6 + 0x20) - temp7]) != temp5) { return var0; }
        else { return storage[0x00]; }
    }

	function solve(var arg0) returns (var r0) {
        var var0 = 0x00;
        var temp0 = arg0; // input
		// temp1 是指针
        var temp1 = memory[0x40:0x60]; // memory[0x40:0x60] = 0x80; temp1 = 0x80
        memory[temp1:temp1 + 0x20] = temp0; //memory[0x80:0xa0] = temp0 = input;
        var temp2 = memory[0x40:0x60]; // temp2 = 0x80
        var var1 = keccak256(memory[temp2:temp2 + (temp1 + 0x20) - temp2]); // var1 = keccak256(input)
        var temp3 = memory[0x40:0x60]; // temp3 = 0x80
        memory[temp3:temp3 + 0x20] = temp0; //memory[0x80:0xa0] = temp0 = input;
        var temp4 = memory[0x40:0x60]; // temp4 = 0x80
        var temp5 = keccak256(memory[temp4:temp4 + (temp3 + 0x20) - temp4]); // temp5 = keccak256(input)
        var temp6 = memory[0x40:0x60]; //temp6 = 0x80
        memory[temp6:temp6 + 0x20] = storage[0x01] * storage[0x02] + storage[0x03];
		// 0x2386f26fc10000 * 0x2e209c0d35750 + 0x16f597de18617d
        var temp7 = memory[0x40:0x60];
    
        if (keccak256(memory[temp7:temp7 + (temp6 + 0x20) - temp7]) != temp5) { return var0; }
        else { return storage[0x00]; }
    }
}
```

## Disassembly

```js
label_0000:
	// Inputs[1] { @0007  msg.data.length }
	0000    60  PUSH1 0x80
	0002    60  PUSH1 0x40
	0004    52  MSTORE
	0005    60  PUSH1 0x04
	0007    36  CALLDATASIZE
	0008    10  LT
	0009    60  PUSH1 0x3f
	000B    57  *JUMPI
	// Stack delta = +0
	// Outputs[1] { @0004  memory[0x40:0x60] = 0x80 }
	// Block ends with conditional jump to 0x003f, if msg.data.length < 0x04

label_000C:
	// Incoming jump from 0x000B, if not msg.data.length < 0x04
	// Inputs[1] { @000E  msg.data[0x00:0x20] }
	000C    60  PUSH1 0x00
	000E    35  CALLDATALOAD
	000F    7C  PUSH29 0x0100000000000000000000000000000000000000000000000000000000
	002D    90  SWAP1
	002E    04  DIV
	002F    63  PUSH4 0xffffffff
	0034    16  AND
	0035    80  DUP1
	0036    63  PUSH4 0x9189fec1
	003B    14  EQ
	003C    60  PUSH1 0x44
	003E    57  *JUMPI
	// Stack delta = +1
	// Outputs[1] { @0034  stack[0] = 0xffffffff & msg.data[0x00:0x20] / 0x0100000000000000000000000000000000000000000000000000000000 }
	// Block ends with conditional jump to 0x0044, if 0x9189fec1 == 0xffffffff & msg.data[0x00:0x20] / 0x0100000000000000000000000000000000000000000000000000000000

label_003F:
	// Incoming jump from 0x003E, if not 0x9189fec1 == 0xffffffff & msg.data[0x00:0x20] / 0x0100000000000000000000000000000000000000000000000000000000
	// Incoming jump from 0x000B, if msg.data.length < 0x04
	// Inputs[1] { @0043  memory[0x00:0x00] }
	003F    5B  JUMPDEST
	0040    60  PUSH1 0x00
	0042    80  DUP1
	0043    FD  *REVERT
	// Stack delta = +0
	// Outputs[1] { @0043  revert(memory[0x00:0x00]); }
	// Block terminates

label_0044:
	// Incoming jump from 0x003E, if 0x9189fec1 == 0xffffffff & msg.data[0x00:0x20] / 0x0100000000000000000000000000000000000000000000000000000000
	// Inputs[1] { @0045  msg.value }
	0044    5B  JUMPDEST
	0045    34  CALLVALUE
	0046    80  DUP1
	0047    15  ISZERO
	0048    60  PUSH1 0x4f
	004A    57  *JUMPI
	// Stack delta = +1
	// Outputs[1] { @0045  stack[0] = msg.value }
	// Block ends with conditional jump to 0x004f, if !msg.value

label_004B:
	// Incoming jump from 0x004A, if not !msg.value
	// Inputs[1] { @004E  memory[0x00:0x00] }
	004B    60  PUSH1 0x00
	004D    80  DUP1
	004E    FD  *REVERT
	// Stack delta = +0
	// Outputs[1] { @004E  revert(memory[0x00:0x00]); }
	// Block terminates

label_004F:
	// Incoming jump from 0x004A, if !msg.value
	// Inputs[2]
	// {
	//     @0056  msg.data.length
	//     @005D  msg.data[0x04:0x24]
	// }
	004F    5B  JUMPDEST
	0050    50  POP
	0051    60  PUSH1 0x6c
	0053    60  PUSH1 0x04
	0055    80  DUP1
	0056    36  CALLDATASIZE
	0057    03  SUB
	0058    81  DUP2
	0059    01  ADD
	005A    90  SWAP1
	005B    80  DUP1
	005C    80  DUP1
	005D    35  CALLDATALOAD
	005E    90  SWAP1
	005F    60  PUSH1 0x20
	0061    01  ADD
	0062    90  SWAP1
	0063    92  SWAP3
	0064    91  SWAP2
	0065    90  SWAP1
	0066    50  POP
	0067    50  POP
	0068    50  POP
	0069    60  PUSH1 0x82
	006B    56  *JUMP
	// Stack delta = +1
	// Outputs[2]
	// {
	//     @0051  stack[-1] = 0x6c
	//     @0063  stack[0] = msg.data[0x04:0x24]
	// }
	// Block ends with call to 0x0082, returns to 0x006C

label_006C:
	// Incoming return from call to 0x0082 at 0x006B
	// Inputs[4]
	// {
	//     @006F  memory[0x40:0x60]
	//     @0071  stack[-1]
	//     @007C  memory[0x40:0x60]
	//     @0081  memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]
	// }
	006C    5B  JUMPDEST
	006D    60  PUSH1 0x40
	006F    51  MLOAD
	0070    80  DUP1
	0071    82  DUP3
	0072    81  DUP2
	0073    52  MSTORE
	0074    60  PUSH1 0x20
	0076    01  ADD
	0077    91  SWAP2
	0078    50  POP
	0079    50  POP
	007A    60  PUSH1 0x40
	007C    51  MLOAD
	007D    80  DUP1
	007E    91  SWAP2
	007F    03  SUB
	0080    90  SWAP1
	0081    F3  *RETURN
	// Stack delta = -1
	// Outputs[2]
	// {
	//     @0073  memory[memory[0x40:0x60]:memory[0x40:0x60] + 0x20] = stack[-1]
	//     @0081  return memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]];
	// }
	// Block terminates

label_0082:
	// Incoming call from 0x006B, returns to 0x006C
	// Inputs[13]
	// {
	//     @0086  stack[-1]
	//     @0089  memory[0x40:0x60]
	//     @0096  memory[0x40:0x60]
	//     @009B  memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]
	//     @00A1  memory[0x40:0x60]
	//     @00AE  memory[0x40:0x60]
	//     @00B3  memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]
	//     @00BA  storage[0x03]
	//     @00BD  storage[0x02]
	//     @00C0  storage[0x01]
	//     @00C5  memory[0x40:0x60]
	//     @00D2  memory[0x40:0x60]
	//     @00D7  memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]
	// }
	0082    5B  JUMPDEST
	0083    60  PUSH1 0x00
	0085    80  DUP1
	0086    82  DUP3
	0087    60  PUSH1 0x40
	0089    51  MLOAD
	008A    80  DUP1
	008B    82  DUP3
	008C    81  DUP2
	008D    52  MSTORE
	008E    60  PUSH1 0x20
	0090    01  ADD
	0091    91  SWAP2
	0092    50  POP
	0093    50  POP
	0094    60  PUSH1 0x40
	0096    51  MLOAD
	0097    80  DUP1
	0098    91  SWAP2
	0099    03  SUB
	009A    90  SWAP1
	009B    20  SHA3
	009C    90  SWAP1
	009D    50  POP
	009E    82  DUP3
	009F    60  PUSH1 0x40
	00A1    51  MLOAD
	00A2    80  DUP1
	00A3    82  DUP3
	00A4    81  DUP2
	00A5    52  MSTORE
	00A6    60  PUSH1 0x20
	00A8    01  ADD
	00A9    91  SWAP2
	00AA    50  POP
	00AB    50  POP
	00AC    60  PUSH1 0x40
	00AE    51  MLOAD
	00AF    80  DUP1
	00B0    91  SWAP2
	00B1    03  SUB
	00B2    90  SWAP1
	00B3    20  SHA3
	00B4    60  PUSH1 0x00
	00B6    19  NOT
	00B7    16  AND
	00B8    60  PUSH1 0x03
	00BA    54  SLOAD
	00BB    60  PUSH1 0x02
	00BD    54  SLOAD
	00BE    60  PUSH1 0x01
	00C0    54  SLOAD
	00C1    02  MUL
	00C2    01  ADD
	00C3    60  PUSH1 0x40
	00C5    51  MLOAD
	00C6    80  DUP1
	00C7    82  DUP3
	00C8    81  DUP2
	00C9    52  MSTORE
	00CA    60  PUSH1 0x20
	00CC    01  ADD
	00CD    91  SWAP2
	00CE    50  POP
	00CF    50  POP
	00D0    60  PUSH1 0x40
	00D2    51  MLOAD
	00D3    80  DUP1
	00D4    91  SWAP2
	00D5    03  SUB
	00D6    90  SWAP1
	00D7    20  SHA3
	00D8    60  PUSH1 0x00
	00DA    19  NOT
	00DB    16  AND
	00DC    14  EQ
	00DD    15  ISZERO
	00DE    60  PUSH1 0xe6
	00E0    57  *JUMPI
	// Stack delta = +2
	// Outputs[5]
	// {
	//     @0083  stack[0] = 0x00
	//     @008D  memory[memory[0x40:0x60]:memory[0x40:0x60] + 0x20] = stack[-1]
	//     @009C  stack[1] = keccak256(memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]])
	//     @00A5  memory[memory[0x40:0x60]:memory[0x40:0x60] + 0x20] = stack[-1]
	//     @00C9  memory[memory[0x40:0x60]:memory[0x40:0x60] + 0x20] = storage[0x01] * storage[0x02] + storage[0x03]
	// }
	// Block ends with conditional jump to 0x00e6, if !(~0x00 & keccak256(memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]) == ~0x00 & keccak256(memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]))

label_00E1:
	// Incoming jump from 0x00E0, if not !(~0x00 & keccak256(memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]) == ~0x00 & keccak256(memory[memory[0x40:0x60]:memory[0x40:0x60] + (0x20 + memory[0x40:0x60]) - memory[0x40:0x60]]))
	// Inputs[4]
	// {
	//     @00E3  storage[0x00]
	//     @00E4  stack[-2]
	//     @00E8  stack[-4]
	//     @00E9  stack[-3]
	// }
	00E1    60  PUSH1 0x00
	00E3    54  SLOAD
	00E4    91  SWAP2
	00E5    50  POP
	00E6    5B  JUMPDEST
	00E7    50  POP
	00E8    91  SWAP2
	00E9    90  SWAP1
	00EA    50  POP
	00EB    56  *JUMP
	// Stack delta = -3
	// Outputs[1] { @00E8  stack[-4] = storage[0x00] }
	// Block ends with unconditional jump to stack[-4]

	00EC    00    *STOP
	00ED    A1    LOG1
	00EE    65    PUSH6 0x627a7a723058
	00F5    20    SHA3
	00F6    B4    B4
	00F7    FD    *REVERT
	00F8    AB    AB
	00F9    71    PUSH18 0x4c1acaa21e2638a572ff5c70f5d44b11601c
	010C    BB    BB
	010D    60    PUSH1 0x19
	010F    C6    C6
	0110    34    CALLVALUE
	0111    CB    CB
	0112    52    MSTORE
	0113    E0    E0
	0114    28    28
	0115    F3    *RETURN
	0116    00    *STOP
	0117    29    29
```